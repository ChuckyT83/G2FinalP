Group 2: Layla Nettaavong Charles Tranter Gautam Mehla

Final Project Summary and Plan

Communication and URLs

We have agreed to communicate to each other via discord. We do small summaries and check ups throughout the day while big check ups are done after class and/or after a task is complete.  Our Github link is here and our trello link is there .

Final Project Summary

Our final project will be a small quiz game, where users have to answer questions based on their video game preferences and styles. The end result will calculate the type of character that user should play as. The front-end simply looks like various questions that save the answers for a sort-of calculator to look at. The back-end will have a list of character types and thier uses, with one character being chosen based on the user's answers.

Team Roles and Responsibilities

Each member has equal responsibility in terms of main coding. Charles Tranter is responsible for … Gautam Mehla is responsible for … and Layla Nettavongis responsible for …
