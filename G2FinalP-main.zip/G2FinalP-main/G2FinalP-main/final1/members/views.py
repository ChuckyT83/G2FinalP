from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.contrib.auth.forms import UserCreationForm

def registerPage(request): #This funtion creates the user account and saves it
    form = UserCreationForm(request.POST)
    if request.method == "POST":    
        if  form.is_valid():
            form.save()
        else:
            return("Your username or password is not valid, please try again.")
    
    context = {'form':form}
    return render (request, 'authenticate/create_login.html' ,context)

def login_user(request): #Function allows user to login in if they have an account
    if request .method == "POST":
        pass
        username = request.POST["username"]
        password = request.POST["password"]
        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            return redirect('index')
            # Redirect to a success page.

        else:
            # Return an 'invalid login' error message.
            messages.success(request,("Please try again"))
            return redirect('login')
        
    else:
        return render(request, 'authenticate/login.html',{})
